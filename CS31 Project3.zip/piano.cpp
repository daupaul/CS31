#include <iostream>
#include <string>
#include <cctype>
#include <cassert>
using namespace std;

bool isTuneWellFormed(string tune);
int translateTune(string tune, string& instructions, int& badBeat);
char translateNote(int octave, char noteLetter, char accidentalSign);

int main()
{
	assert(isTuneWellFormed("D5//D/"));
	assert(!isTuneWellFormed("D5//Z/"));
	string instrs;
	int badb;
	instrs = "xxx"; badb = -999; // so we can detect whether these get changed
	assert(translateTune("D5//D/", instrs, badb) == 0 && instrs == "R H"  &&  badb == -999);
	instrs = "xxx"; badb = -999; // so we can detect whether these get changed
	assert(translateTune("D5//Z/", instrs, badb) == 1 && instrs == "xxx"  &&  badb == -999);
	assert(translateTune("D5//D8/", instrs, badb) == 2 && instrs == "xxx"  &&  badb == 3);
		cerr << "All tests succeeded" << endl;
}

bool isTuneWellFormed(string tune)
{
	if (tune == "") // no beats at all
		return true;
	else // one or more beats
	{
		for (int k = 0; k != tune.size(); k++)
		{
			if (k == tune.size() - 1 && tune[k - 1] == '/') // if all previous characters pass the examination and the last character is /
				return true;
			else if (tune[k] == '/') // if several beats are in a tune
				continue;
			else if (tune[k] == ' ') // if space is in a tune
				return false;
			else if (tune[k] >= 'A' && tune[k] <= 'G') // if character is between A and G
			{
				if (tune[k + 1] == '/') // if the next character is /
					continue;
				else if (tune[k + 1] >= '0' && tune[k + 1] <= '9') // if the next character is between 0 and 9
				{
					if (tune[k + 2] == '/') // and after the next is /
					{
						k++; // start from the /
						continue;
					}
					else if (tune[k + 2] >= 'A' && tune[k + 2] <= 'G') // after the next is a new note
					{
						k++; // start from the new note
						continue;
					}
					else
						return false;
				}
				else if (tune[k + 1] == '#' || tune[k + 1] == 'b') // if character is between A and G and the next character is an accidental sign
				{
					if (tune[k + 2] == '/') // and after the next is a /
					{
						k++; // start from the /
						continue;
					}
					else if (tune[k + 2] >= '0' && tune[k + 2] <= '9') // and after the next is between 0 and 9
					{
						if (tune[k + 3] == '/') // if this note ends with /
						{
							k = k + 2; // start from the /
							continue;
						}
						else if (tune[k + 3] >= 'A' && tune[k + 3] <= 'G') // if this note ends with a new note
						{
							k = k + 2; // start from the new note
							continue;
						}
						else
							return false;
					}
					else if (tune[k + 2] >= 'A' && tune[k + 2] <= 'G') // if this note ends with a new note
					{
						k++; // start from the new note
						continue;
					}
					else
						return false;
				}
				else if (tune[k + 1] >= 'A' && tune[k + 1] <= 'G') // if character is between A and G and the next character is a new note
					continue;
				else
					return false;
			}
			else if (tune[k] >= 'H' && tune[k] <= 'Z') // if character is bewtween H and Z
				return false;
			else
				return false;
		}
	return true;
	}
}
int translateTune(string tune, string& instructions, int& badBeat)
{
	if (tune == "")
	{
		instructions = ""; // empty string gives empty string
		return 0;
	}
	else if (!isTuneWellFormed(tune)) // if tune is not well-formed
		return 1;
	else 
	{
			for (int k = 0; k != tune.size(); k++)
			{
				if (isdigit(tune[k]))
				{
					if (tune[k] -'0' > 5 || tune[k] - '0' < 2) // if digit isn't between 2 and 5
					{
						int slash = 0;
						for (int i = 0; i < k; i++)
						{
							if (tune[i] == '/')
								slash++;  // determine the location of bad beat
							else
								continue;
						}
						badBeat = slash + 1;
						return 2; // if digit isn't between 2 and 5, this tune well-formed but not playable
					}
					else
						continue;
				}
			
				else if (tune[k] == 'C' && tune[k + 1] == 'b' && tune[k + 2] == '2') // if Cb2 is in the tune
				{
					int slash = 0;
					for (int i = 0; i < k; i++)
					{
						if (tune[i] == '/')
							slash++; //determine the location of Cb2 
						else
							continue;
					}
					badBeat = slash + 1;
					return 2; // Cb2 is well-formed but not playable
				}
				else
					continue;
			}

		string translation = ""; // translated notes in one beat
		string translated = ""; // beats have been translated
		for (int k = 0; k != tune.size(); k++)
		{
			if (isalpha(tune[k])) // if it's the start on a new note
			{
				if (tune[k + 1] == 'b' || tune[k + 1] == '#')
				{
					if (isdigit(tune[k + 2]))
					{
						translation += translateNote(tune[k + 2] - '0', tune[k], tune[k + 1]); // translate note with letter and accidental sign and octave number
						k = k + 2; // start after this note
					}
					else
					{
						translation += translateNote(4, tune[k], tune[k + 1]); // translate note with letter and accidental sign
						k++; // start after this note
					}
				}
				else if (isdigit(tune[k + 1]))
				{
					translation += translateNote(tune[k + 1]-'0', tune[k], ' '); // translate note with letter and octave number
					k++; // start after this note
				}
				else
					translation += translateNote(4, tune[k], ' '); // translate note with letter only
			}
			else if (tune[k] == '/') // represent the end of this beat
			{
				if (translation.size() > 1)
				{
					translation = "[" + translation + "]"; // if this beat has more than one note, put a bracket outside
					translated += translation;
					translation = ""; // the next beat should start to translate with empty string
				}
				else if (translation.size() == 1) // if this beat has exactly one note
				{
					translated += translation;
					translation = ""; // the next beat should start to translate with empty string
				}
				else if (translation.size() == 0) 
				{
					translation = " "; // if this beat is empty, put a space
					translated += translation;
					translation = ""; // the next beat should start to translate with empty string
				}
			}
		}
		instructions = translated;
		return 0; // tune well-formed and playable
	}
	
}
char translateNote(int octave, char noteLetter, char accidentalSign)
{
	// This check is here solely to report a common CS 31 student error.
	if (octave > 9)
	{
		cerr << "********** translateNote was called with first argument = "
			<< octave << endl;
	}

	// Convert Cb, C, C#/Db, D, D#/Eb, ..., B, B#
	//      to -1, 0,   1,   2,   3, ...,  11, 12

	int note;
	switch (noteLetter)
	{
	case 'C':  note = 0; break;
	case 'D':  note = 2; break;
	case 'E':  note = 4; break;
	case 'F':  note = 5; break;
	case 'G':  note = 7; break;
	case 'A':  note = 9; break;
	case 'B':  note = 11; break;
	default:   return ' ';
	}
	switch (accidentalSign)
	{
	case '#':  note++; break;
	case 'b':  note--; break;
	case ' ':  break;
	default:   return ' ';
	}

	// Convert ..., A#1, B1, C2, C#2, D2, ... to
	//         ..., -2,  -1, 0,   1,  2, ...

	int sequenceNumber = 12 * (octave - 2) + note;

	string keymap = "Z1X2CV3B4N5M,6.7/A8S9D0FG!H@JK#L$Q%WE^R&TY*U(I)OP";
	if (sequenceNumber < 0 || sequenceNumber >= keymap.size())
		return ' ';
	return keymap[sequenceNumber];
}