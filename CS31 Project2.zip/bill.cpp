#include <iostream>
#include <string>
using namespace std;

int main()
{
	cout << "Minutes used: ";
	int minUsed;
	cin >> minUsed;

	cout << "Text messages: ";
	int textMsg;
	cin >> textMsg;
	cin.ignore(10000,'\n');

	cout << "Customer name: ";
	string customerName;
	getline(cin, customerName);

	cout << "Month number (1=Jan, 2=Feb, etc.): ";
	int monthNumber;
	cin >> monthNumber;

	cout.setf(ios::fixed);
	cout.precision(2);
	double amountPay;
	if (minUsed <= 500 && textMsg <= 200)
		amountPay = 40;
	else if (minUsed <= 500 && textMsg > 200 && textMsg <= 400)
	{
		if (monthNumber >= 6 && monthNumber <= 9)
			amountPay = 40 + (textMsg - 200) * 0.02;
		else 
			amountPay = 40 + (textMsg - 200) * 0.03;
	}
	else if (minUsed <= 500 && textMsg > 400)
	{
		if (monthNumber >= 6 && monthNumber <= 9)
			amountPay = 40 + 200 * 0.02 + (textMsg - 400) * 0.11;
		else
			amountPay = 40 + 200 * 0.03 + (textMsg - 400) * 0.11;
	}
	else if (minUsed > 500 && textMsg <= 200)
		amountPay = 40 + (minUsed - 500) * 0.45;
	else if (minUsed > 500 && textMsg > 200 && textMsg <= 400)
	{
		if (monthNumber >= 6 && monthNumber <= 9)
			amountPay = 40 + (minUsed - 500) * 0.45 + (textMsg - 200) * 0.02;
		else
			amountPay = 40 + (minUsed - 500) * 0.45 + (textMsg - 200) * 0.03;
	}
	else
	{
		if (monthNumber >= 6 && monthNumber <= 9)
			amountPay = 40 + (minUsed - 500) * 0.45 + 200 * 0.02 + (textMsg - 400) * 0.11;
		else
			amountPay = 40 + (minUsed - 500) * 0.45 + 200 * 0.03 + (textMsg - 400) * 0.11;
	}

		cout << "---" << endl;

	if (minUsed < 0)
		cout << "The number of minutes used must be nonnegative.";
	else if (textMsg < 0)
		cout << "The number of text messages must be nonnegative.";
	else if (customerName == "")
		cout << "You must enter a customer name.";
	else if (monthNumber > 12 || monthNumber < 1)
		cout << "The month number must be in the range 1 through 12.";
	else
		cout << "The bill for " << customerName << " is $" << amountPay;
}