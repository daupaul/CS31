#include <iostream>
#include <string>
#include <cassert>
#include <cctype>
using namespace std;

int appendToAll(string a[], int n, string value);
int lookup(const string a[], int n, string target);
int positionOfMax(const string a[], int n);
int rotateLeft(string a[], int n, int pos);
int rotateRight(string a[], int n, int pos);
int flip(string a[], int n);
int differ(const string a1[], int n1, const string a2[], int n2);
int subsequence(const string a1[], int n1, const string a2[], int n2);
int lookupAny(const string a1[], int n1, const string a2[], int n2);
int separate(string a[], int n, string separator);

int main()
{

}

int appendToAll(string a[], int n, string value)
{
	if (n > 0)
	{
		for (int k = 0; k != n; k++)
			a[k] += value;
		return n;
	}
	else if (n == 0)
		return 0;
	else
		return -1;
}
int lookup(const string a[], int n, string target)
{
	if (n > 0) 
	{
		for (int k = 0; k != n; k++)
			{
				if (a[k] == target)
					return k;
				else
					continue;
			}
		return -1;
	}
	else
		return -1;
}
int positionOfMax(const string a[], int n)
{
	if (n > 0)
	{
		string max = a[0];
		int numberOfmax = 0;
		for (int k = 1; k != n; k++)
		{
			if (a[k] > max)
			{
				max = a[k];
				numberOfmax = k;
			}
			else
				continue;
		}
		return numberOfmax;
	}
	else
		return -1;
}
int rotateLeft(string a[], int n, int pos)
{
	if (n > 0)
	{
		string copy = a[pos];
		int k = pos + 1;
		for (; k != n - 1; k++)
			a[k - 1] = a[k];
		a[k] = copy;
		return pos;
	}
	else
		return -1;
}
int rotateRight(string a[], int n, int pos)
{
	if (n > 0)
	{
		string copy = a[pos];
		for (int k = 0; k != pos; k++)
			a[k] = a[k + 1];
		a[1] = copy;
		return pos;
	}
	else
		return -1;
}
int flip(string a[], int n)
{
	if (n >= 0)
	{
		string b[1000];
		int x = 1;
		for (int k = 0; k != n; k++)
		{
			b[k] = a[n - x];
			x++;
		}
		for (int i = 0; i != n; i++)
			a[i] = b[i];
		return n;
	}
	else
		return -1;
}
int differ(const string a1[], int n1, const string a2[], int n2)
{
	if (n1 > 0 && n2 > 0)
	{
		for (int k = 0; k != n1 && k != n2; k++)
		{
			if (a1[k] == a2[k])
				continue;
			else
				return k;
		}
		if (n1 >= n2)
			return n2;
		else
			return n1;
	}
	else if (n1 == 0 || n2 == 0)
		return 0;
	else
		return -1;
}
int subsequence(const string a1[], int n1, const string a2[], int n2)
{
	if (n1 > 0 && n2 > 0)
	{
		for (int k = 0; k != n1; k++)
		{
			if (a1[k] == a2[0])
			{
				for (int i = 0; i != n2; i++)
				{
					if (i == n2 - 1 && a1[k + i] == a2[i])
						return k;
					else if (a1[k + i] == a2[i])
						continue;
					else
						break;
				}
			}
			else
				continue;
		}
		return -1;
	}
	else
		return -1;
}
int lookupAny(const string a1[], int n1, const string a2[], int n2)
{
	if (n1 > 0 && n2 > 0)
	{
		for (int k = 0; k != n1; k++)
		{
			for (int i = 0; i != n2; i++)
			{
				if (a1[k] == a2[i])
					return k;
				else
					continue;
			}
		}
		return -1;
	}
	else
		return -1;
}
int separate(string a[], int n, string separator)
{
	if (n > 0)
	{
		int k = 0;
		int position;
		string newa[1000];
		for (int i = 0; i != n; i++)
		{
			if (a[i] < separator)
			{
				a[i] = newa[k];
				k++;
			}
			else
				continue;
		}
		position = k;
		for (int i = 0; i != n; i++)
		{
			if (a[i] == separator)
			{
				a[i] = newa[k];
				k++;
			}
			else
				continue;
		}
		for (int i = 0; i != n; i++)
		{
			if (a[i] > separator)
			{
				a[i] = newa[k];
				k++;
			}
			else
				continue;
		}
		return position;
	}
	else
		return -1;
}