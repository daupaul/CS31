#define _CRT_SECURE_NO_WARNINGS
#include <iostream>
#include <cctype>
#include <cstring>
#include <cassert>
using namespace std;

const int MAX_WORD_LENGTH = 20;
int standardizeRules(int distance[],
	char word1[][MAX_WORD_LENGTH + 1],
	char word2[][MAX_WORD_LENGTH + 1],
	int nRules);
int determineQuality(const int distance[],
	const char word1[][MAX_WORD_LENGTH + 1],
	const char word2[][MAX_WORD_LENGTH + 1],
	int nRules,
	const char document[]);

int main()
{
	const int TEST1_NCRITERIA = 4;
	int test1dist[TEST1_NCRITERIA] = {
		2, 4, 1, 13
	};
	char test1w1[TEST1_NCRITERIA][MAX_WORD_LENGTH + 1] = {
		"mad", "deranged", "nefarious", "have"
	};
	char test1w2[TEST1_NCRITERIA][MAX_WORD_LENGTH + 1] = {
		"scientist", "robot", "plot", "mad"
	};
	assert(determineQuality(test1dist, test1w1, test1w2, TEST1_NCRITERIA,
		"The mad UCLA scientist unleashed a deranged evil giant robot.") == 2);
	assert(determineQuality(test1dist, test1w1, test1w2, TEST1_NCRITERIA,
		"The mad UCLA scientist unleashed    a deranged robot.") == 2);
	assert(determineQuality(test1dist, test1w1, test1w2, TEST1_NCRITERIA,
		"**** 2014 ****") == 0);
	assert(determineQuality(test1dist, test1w1, test1w2, TEST1_NCRITERIA,
		"  That plot: NEFARIOUS!") == 1);
	assert(determineQuality(test1dist, test1w1, test1w2, TEST1_NCRITERIA,
		"deranged deranged robot deranged robot robot") == 1);
	assert(determineQuality(test1dist, test1w1, test1w2, TEST1_NCRITERIA,
		"Two mad scientists suffer from deranged-robot fever.") == 0);
	cout << "All tests succeeded" << endl;
}
int standardizeRules(int distance[],
	char word1[][MAX_WORD_LENGTH + 1],
	char word2[][MAX_WORD_LENGTH + 1],
	int nRules)
{
	for (int k = 0; k != nRules; k++)
	{
		for (int i = 0; word1[k][i] != '\0'; i++)
			word1[k][i] = tolower(word1[k][i]); //change every letter in word1 to lower case
	}
	for (int k = 0; k != nRules; k++)
	{
		for (int i = 0; word2[k][i] != '\0'; i++)
			word2[k][i] = tolower(word2[k][i]); //change every letter in word2 to lower case
	}

	for (int k = 0; k != nRules - 1; k++)
	{
		for (int i = k + 1; i != nRules; i++) // i = k + 1 prevent from cheching the word itself and the word has been checked
		{
			if (strcmp(word1[k], word1[i]) == 0 && strcmp(word2[k], word2[i]) == 0) //match rule has the same w1 and w2 word
			{
				if (distance[k] >= distance[i]) 
				{
					for (int j = i; j != nRules - 1; j++) //eliminate the one with smaller distance
					{
						strcpy(word1[j], word1[j + 1]);
						strcpy(word2[j], word2[j + 1]);
						distance[j] = distance[j + 1]; 
					}
					k--; // back to the previous rule so that it will not miss any rule check
					i--; // if the rule is the last rule, i-- prevent the check exceeds nRules
					nRules--; //number of rule in standard form 
				}
				else
				{
					for (int j = k; j != nRules - 1; j++) //eliminate the one with smaller distance
					{
						strcpy(word1[j], word1[j + 1]);
						strcpy(word2[j], word2[j + 1]);
						distance[j] = distance[j + 1];
					}
					k--; // back to the previous rule so that it will not miss any rule check
					i--; // if the rule is the last rule, i-- prevent the check exceeds nRules
					nRules--; //number of rule in standard form 
				}
			}
			
			else if (strcmp(word1[k], word2[i]) == 0 && strcmp(word2[k], word1[i]) == 0) // w1[k] == w2[i] and w2[k] == w1[i] 
			{
				if (distance[k] >= distance[i])
				{
					for (int j = i; j != nRules - 1; j++) //eliminate the one with smaller distance
					{
						strcpy(word1[j], word1[j + 1]);
						strcpy(word2[j], word2[j + 1]);
						distance[j] = distance[j + 1];
					}
					k--; // back to the previous rule so that it will not miss any rule check
					i--; // if the rule is the last rule, i-- prevent the check exceeds nRules
					nRules--; //number of rule in standard form 
				}
				else
				{
					for (int j = k; j != nRules - 1; j++) //eliminate the one with smaller distance
					{
						strcpy(word1[j], word1[j + 1]);
						strcpy(word2[j], word2[j + 1]);
						distance[j] = distance[j + 1];
					}
					k--; // back to the previous rule so that it will not miss any rule check
					i--; // if the rule is the last rule, i-- prevent the check exceeds nRules
					nRules--; //number of rule in standard form 
				}
			}
			else
				continue;
		}
	}
	
	for (int k = 0; k != nRules; k++)
	{
		if (strcmp(word1[k], "") == 0 || strcmp(word2[k], "") == 0) //contain no characters
		{
			for (int j = k; j != nRules - 1; j++) //delete this rule
			{
				strcpy(word1[j], word1[j + 1]);
				strcpy(word2[j], word2[j + 1]);
				distance[j] = distance[j + 1];
			}
			k--; //start from the next rule
			nRules--; //number of rule in standard form 
		}
		else if (distance[k] <= 0) //distance is negative or 0
		{
			for (int j = k; j != nRules - 1; j++) //delete this rule
			{
				strcpy(word1[j], word1[j + 1]);
				strcpy(word2[j], word2[j + 1]);
				distance[j] = distance[j + 1];
			}
			k--; //start from the next rule
			nRules--; //number of rule in standard form 
		}
		else
		{
			for (int i = 0; word1[k][i] != '\0'; i++)
			{
				if (!islower(word1[k][i])) //if word in w1 contain anything other than letters
				{
					for (int j = k; j != nRules - 1; j++) //delete this rule
					{
						strcpy(word1[j], word1[j + 1]);
						strcpy(word2[j], word2[j + 1]);
						distance[j] = distance[j + 1];
					}
					k--; //start from the next rule
					nRules--; //number of rule in standard form 
				}
				else
					continue;
			}
			for (int i = 0; word2[k][i] != '\0'; i++) //if word in w2 contain anything other than letters
			{
				if (!islower(word2[k][i]))
				{
					for (int j = k; j != nRules - 1; j++) //delete this rule
					{
						strcpy(word1[j], word1[j + 1]);
						strcpy(word2[j], word2[j + 1]);
						distance[j] = distance[j + 1];
					}
					k--; //start from the next rule
					nRules--; //number of rule in standard form 
				}
				else
					continue;
			}
		}
	}

	return nRules;
}
int determineQuality(const int distance[],
	const char word1[][MAX_WORD_LENGTH + 1],
	const char word2[][MAX_WORD_LENGTH + 1],
	int nRules,
	const char document[])
{
	const int MAX_DOCUMENT = 200;
	char newDocument[MAX_DOCUMENT + 1]; //this new document contain only lower case letter and space
	int nnewDoc = 0; //number of characters in new document
	for (int k = 0;; k++)
	{
		if (islower(document[k])) //put lower case letter into new document
		{
			newDocument[nnewDoc] = document[k];
			nnewDoc++;
		}
		else if (isupper(document[k])) //change upper case letter to lower case and put it into new document
		{
			newDocument[nnewDoc] = tolower(document[k]); 
			nnewDoc++;
		}
		else if (document[k] == ' ') //space is considered as word separator
		{
			newDocument[nnewDoc] = document[k];
			nnewDoc++;
			for (int i = k; document[i] != '\0'; i++) //several spaces are still considered as one separator
			{
				if (document[i + 1] == ' ')
					k++; //start to check from the next character
				else
					break;
			}
		}
		else if (document[k] == '\0') // if the document has ended
		{
			newDocument[nnewDoc] = '\0'; //end the new document
			break;
		}
		else
			continue; //ignore the characters other than letter, ' ', '\0'
	}

	char documentWord[MAX_DOCUMENT + 1][MAX_DOCUMENT + 1]; // change the new document into array
	int numberDocWord = 0; //number of words in new document
	for (int k = 0; newDocument[k] != '\0' ; k++)
	{
		char nowWord[MAX_DOCUMENT + 1]; //the transmitting word
		int nnowWord = 0; // number of letters
		for (int i = k;; i++)
		{
			if (islower(newDocument[i])) //copy the letter to transmitting word
			{
				nowWord[nnowWord] = newDocument[i];
				nnowWord++;
				k++; //keep the value of k same as i, so it will not repeat transmitting the same word
			}
			else if (newDocument[i] == ' ') //space is separator, representing the end of a word
			{
				nowWord[nnowWord] = '\0'; //end the transmitting word
				strcpy(documentWord[numberDocWord], nowWord); //put it into array
				numberDocWord++;
				break; //end the loop to start to transmit the next word
			}
			else if (newDocument[i] == '\0') //if this is the end of new document
			{
				nowWord[nnowWord] = '\0'; //end the transmitting word
				strcpy(documentWord[numberDocWord], nowWord); //put it into array
				numberDocWord++;
				k--; //prevent k from exceeding nnewDoc
				break; //end the inner loop, and the outer loop will end as well due to its condition
			}
			else
				continue;
		}
	}
	
	int matchRule = 0;
	for (int k = 0; k != nRules; k++)
	{
		for (int i = 0; i != numberDocWord; i++) //compare the word in w1 with the word in document array
		{
			if (strcmp(word1[k], documentWord[i]) == 0) //if there is a match between w1 and document
			{
				for (int j = 0; j != numberDocWord; j++)
				{
					if (strcmp(word2[k], documentWord[j]) == 0) //look for w2
					{
						if (i - j > 0 && i - j <= distance[k]) //if the distance between w1 and w2 is in demanded distance
						{
							matchRule++;
							k++; //start to check from the next rule
							i = 0;
							break;
						}
						else if (j - i > 0 && j - i <= distance[k]) //if the distance between w1 and w2 is in demanded distance
						{
							matchRule++;
							k++; //start to check from the next rule
							i = 0;
							break;
						}
						else
							continue;
					}
					else
						continue;
				}
			}
			else
				continue;
		}
	}
	return matchRule;
}



